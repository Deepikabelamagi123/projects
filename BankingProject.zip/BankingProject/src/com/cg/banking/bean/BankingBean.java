package com.cg.banking.bean;

public class BankingBean 
{

	int accountNumber;
	int openingBalance;
	String name;
	String mobile;
	String panNumber;
	String IFSCcode;
	String branch;
	String mail;
	String userId;
	String password;
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public int getOpeningBalance(int accountNumber) {
		return openingBalance;
	}
	public void setOpeningBalance(int openingBalance) {
		this.openingBalance = openingBalance;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public String getIFSCcode() {
		return IFSCcode;
	}
	public void setIFSCcode(String IFSCcode) {
		this.IFSCcode = IFSCcode;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public BankingBean(int openingBalance, String name, String mobile,
			String panNumber, String IFSCcode, String branch, String mail,
			String userId, String password) {
		this.openingBalance = openingBalance;
		this.name = name;
		this.mobile = mobile;
		this.panNumber = panNumber;
		this.IFSCcode = IFSCcode;
		this.branch = branch;
		this.mail = mail;
		this.userId = userId;
		this.password = password;
	}
	public BankingBean() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		
		return "name: "+this.name+"oprningbalance :"+this.openingBalance+
				"accountnumber: "+this.accountNumber;
	}
	
}
