package com.cg.banking.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.banking.bean.BankingBean;
import com.cg.banking.bean.BankingTransactionBean;


public class BankingImplDao implements IbankingDao {
	static BankingBean ban=new BankingBean();

	static Map<Integer, BankingTransactionBean> transactionlist=new HashMap<Integer, BankingTransactionBean>();

	static Map<Integer, BankingBean> accountlist=new HashMap<Integer, BankingBean>();

	static BankingTransactionBean bantransbean=new BankingTransactionBean();

	@Override
	public int  createAccount(BankingBean ban, BankingTransactionBean transaction) {
		accountlist.put(ban.getAccountNumber(), ban);
		transactionlist.put(transaction.getTransactionId(), transaction);
		return ban.getAccountNumber();				
	}
	@Override
	public int showBalance(int accountNumber) {
		BankingBean ban=accountlist.get(accountNumber);		
		return ban.getOpeningBalance(accountNumber);				
	}

	@Override
	public int  deposit(int accountNumber,int depositAmount,BankingTransactionBean transaction) {
		BankingBean ban=accountlist.get(accountNumber);
		if (ban!=null)
		{
		int finalAmount=ban.getOpeningBalance(accountNumber)+depositAmount;
		ban.setOpeningBalance(finalAmount);
		transactionlist.put(transaction.getTransactionId(), transaction);
		}
		return ban.getOpeningBalance(accountNumber);
		
	}

	@Override
	public int withdraw(int accountNumber,int withdrawnAmount,BankingTransactionBean transaction) {
		BankingBean ban=accountlist.get(accountNumber);
		if(ban!=null)
		{
			if(ban.getOpeningBalance(accountNumber)>withdrawnAmount)
			{
				int amount=ban.getOpeningBalance(accountNumber)-withdrawnAmount;
				ban.setOpeningBalance(amount);
				transactionlist.put(transaction.getTransactionId(), transaction);
			}
		}
		
		return ban.getOpeningBalance(accountNumber);
		
		
	}

	@Override
	public int fundTransfer(int fromAccountNumber,int toAccountNumber,int amount,String userId,String password,BankingTransactionBean transaction) {
		BankingBean ban1=accountlist.get(fromAccountNumber);
		BankingBean ban2=accountlist.get(toAccountNumber);
		if(ban1!=null&&ban2!=null)
		{
			if(userId.equals(ban1.getUserId())&&password.equals(ban1.getPassword()))
			{
			int remainingbalban1=ban1.getOpeningBalance(fromAccountNumber)-amount;
			int finalbalban2 =ban2.getOpeningBalance(toAccountNumber)+amount;
			ban1.setOpeningBalance(remainingbalban1);
			ban2.setOpeningBalance(finalbalban2);
			bantransbean.setTypeOfTransaction("Funds Transfered");
			transactionlist.put(transaction.getTransactionId(), transaction);
			return ban1.getOpeningBalance(fromAccountNumber);
			}
			else
			{
				return 0;
				}
		}
		else
		{
			return 0;
		}
		
	}

	@Override
	public HashMap<Integer, BankingTransactionBean> printTransactions() {
		 HashMap<Integer, BankingTransactionBean> transaction = (HashMap<Integer, BankingTransactionBean>) transactionlist;
		 
		 return transaction;
		
	}
	
	

}
