package com.cg.banking.dao;

import java.util.HashMap;

import com.cg.banking.bean.BankingBean;
import com.cg.banking.bean.BankingTransactionBean;

public interface IbankingDao {

	public int showBalance(int accountNumber);

	public int deposit(int accountNumber,int depositAmount,BankingTransactionBean transaction);

	public int withdraw(int accountNumber,int withdrawnAmount,BankingTransactionBean transaction);

	public int fundTransfer(int fromAccountNumber,int toAccountNumber,int amount,String userId,String password,BankingTransactionBean transaction);

	public HashMap<Integer, BankingTransactionBean> printTransactions();

	int createAccount(BankingBean ban, BankingTransactionBean transaction);

}
