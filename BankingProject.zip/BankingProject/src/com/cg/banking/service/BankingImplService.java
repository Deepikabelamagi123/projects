package com.cg.banking.service;

import java.util.HashMap;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.banking.bean.BankingBean;
import com.cg.banking.bean.BankingTransactionBean;
import com.cg.banking.dao.BankingImplDao;
import com.cg.banking.dao.IbankingDao;

public class BankingImplService implements IBankingService{
	public  boolean h;
	static BankingTransactionBean bantransbean=new BankingTransactionBean();
	static IbankingDao iband=null;
	private int generateAccountNum(){
		Random rd=new Random();
		return  rd.nextInt(10000000);
	}
	private int generateTransactionId(){
		Random rd=new Random();
		return  rd.nextInt(100000000);
	}
	@Override
	public int createAccount(BankingBean ban,BankingTransactionBean transaction) {
		iband=new BankingImplDao();
		ban.setAccountNumber(generateAccountNum());	
		transaction.setTransactionId(generateTransactionId());
		transaction.setAccountNumber(ban.getAccountNumber());
		return iband.createAccount(ban,transaction);			
	}
	@Override
	public int showBalance(int accountNumber) {
		iband=new BankingImplDao();
		return iband.showBalance(accountNumber);		
	}
	@Override
	public int deposit(int accountNumber,int depositAmount,BankingTransactionBean transaction) {
		iband=new BankingImplDao();
		transaction.setTransactionId(generateTransactionId());
		transaction.setAccountNumber(accountNumber);
		return iband.deposit(accountNumber,depositAmount,transaction);				
	}
	@Override
	public int withdraw(int accountNumber,int withdrawnAmount,BankingTransactionBean transaction) {
		iband=new BankingImplDao();
		transaction.setTransactionId(generateTransactionId());
		transaction.setAccountNumber(accountNumber);
		return iband.withdraw(accountNumber, withdrawnAmount,transaction);		
	}
	@Override
	public int fundTransfer(int fromAccountNumber,int toAccountNumber,int amount,String userId,String password,BankingTransactionBean transaction) {
		iband=new BankingImplDao();
		transaction.setTransactionId(generateTransactionId());
		transaction.setAccountNumber(fromAccountNumber);
	return	iband.fundTransfer(fromAccountNumber, toAccountNumber, amount,userId,password,transaction);
		
	}
	@Override
	public HashMap<Integer, BankingTransactionBean> printTransactions() {
		
		
		iband=new BankingImplDao();
		
		
		return iband.printTransactions();		
	}
	
	
	public void validationName(String name)
	{
		Pattern p=Pattern.compile("^[A-Z]{1}\\w{3,}");
		Matcher m=p.matcher(name);
		if(name.charAt(1)>90)
		{
		if(m.find()){
		 h=true;
		}
		else
		{
			System.out.println("your name is not proper");
		h=false;	
		}
		}
		else
		{
			System.out.println("your name is not proper");
		h=false;	
		}
	
	}
	public void validationMob(String mob)
	{
		Pattern p=Pattern.compile("^[6-9]\\d{9}");
		Matcher m=p.matcher(mob);
		if(m.find()){
		 h=true;
		}
		else
		{System.out.println("enter proper mobile number");
			h=false;
		}
		}
	public void validationPan(String pan)
	{
		Pattern p=Pattern.compile("^[A-Z]{3}\\d{7}");
		Matcher m=p.matcher(pan);
		if(m.find()){
		 h=true;
		}
		else
		{System.out.println("enter proper pan number");
			h=false;
		}
		}
	public void validationIfsc(String IFSCcode)
	{
		Pattern p=Pattern.compile("^[A-Z]{4}\\d{5}");
		Matcher m=p.matcher(IFSCcode);
		if(m.find()){
		 h=true;
		}
		else
		{System.out.println("enter proper IFSC number");
			h=false;
		}
		}
	public void validationAccBalance(int balance)
	{
		if(balance>=5000)
		{
			h=true;
		}
		else
		{
			System.out.println("min balance required is 5000");
			h=false;
		}
	}
	public void validatepassword(String pwd) 
	{
		if (pwd.length()>8)
		{
			h=true;
			System.out.println("password is valid");
		}
		else
		{
			System.out.println("length of password should be more then 8");
			h=false;
			
		}
	}
	public void validateMail(String mail)
	{
		if(mail.contains("@gmail.com"))
		{
			System.out.println("your mail is valid");
			h=true;
		}
		else
		{
		System.out.println("mail is not valid please enter again \n your mail should contain @gmail.com");
		h=false;
		}
	}
	
	
	
}
