package com.cg.banking.service;

import java.util.HashMap;

import com.cg.banking.bean.BankingBean;
import com.cg.banking.bean.BankingTransactionBean;

public interface IBankingService {
	public int createAccount(BankingBean ban, BankingTransactionBean transaction);

	public int deposit(int accountNumber,int depositAmount,BankingTransactionBean transaction);

	public int withdraw(int accountNumber,int withdrawAmount,BankingTransactionBean transaction);

	public int fundTransfer(int fromAccountNumber,int toAccountNumber,int amount,String userId,String password,BankingTransactionBean transaction);

	HashMap<Integer, BankingTransactionBean> printTransactions();
	int showBalance(int accountNumber);

}
