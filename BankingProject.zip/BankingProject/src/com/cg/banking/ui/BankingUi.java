package com.cg.banking.ui;

import java.util.Collection;
import java.util.HashMap;
import java.util.Scanner;

import com.cg.banking.bean.BankingBean;
import com.cg.banking.bean.BankingTransactionBean;
import com.cg.banking.service.BankingImplService;
import com.cg.banking.service.IBankingService;

public class BankingUi {
static Scanner scan=new Scanner(System.in);
static IBankingService ibserv=null;
static int accountNumber;
static BankingImplService biserv=new BankingImplService();
	public static void main(String[] args) {
		int i=1;
		System.out.println("------------BANK APPLICATION-------------");
		do{
		System.out.println("--------Select an option from below list----------");
		System.out.println(" 1. createAccount \n 2. showBalance \n 3. deposit \n "
				+ "4. withdraw \n 5. fundTransfer \n 6. printTransactions ");
		switch(scan.nextInt())
		{
		case 1:
			
			int finalempid=createAccount();
			System.out.println("account info is stored");
			System.out.println("ur account id is "+finalempid);
			break;
		case 2:
			System.out.println("-----enter account number to display balance-----");
			int finalBalance=showBalance(scan.nextInt());
			System.out.println("Your available balance is : "+finalBalance);
			break;
		case 3:
			System.out.println("-----enter account number to deposit-----");
			 accountNumber=scan.nextInt();
			System.out.println("-----enter amount to be deposited-------");
			int depositAmount=scan.nextInt();
			int balance=deposit(accountNumber,depositAmount);
			System.out.println("your balance is : "+balance);
			break;
		case 4:
			System.out.println("-----enter account number to withdrawn-----");
			 accountNumber=scan.nextInt();
			 System.out.println("-----enter amount to be withdrawn-------");
				int withdrawnAmount=scan.nextInt();
			int remainingBalance=withdraw(accountNumber,withdrawnAmount);
			System.out.println("you withdrawn an amount of : "+withdrawnAmount+
					"\n --remaining balance is :   "+remainingBalance);
			break;
		case 5:
			fundTransfer();
			break;
		case 6:
			printTransactions();
			break;	
		default :
			System.out.println("----enter valid option----");
			break;
		}
			
		}while(i<10);
	}
		public static int createAccount()
		{	boolean b = true;
			
			String name="";
			String mobile="";
			String panNumber="";
			String IFSCcode="";
			String branch="";			
			String mail="";
			String userId="";
			String password = "";
			int openingBalance;
			
			do
			{
			System.out.println("-----Enter your Name first letter should be capital---");
			name=scan.next();
			biserv.validationName(name);
			}while(biserv.h==false);
			do
			{
			System.out.println("-----Enter your Mobile Number---");
			mobile=scan.next();
			biserv.validationMob(mobile);
			}while(biserv.h==false);
			do
			{
			System.out.println("-----Enter your PAN Number---");
			panNumber=scan.next();
			biserv.validationPan(panNumber);
			}while(biserv.h==false);
			do
			{
			System.out.println("-----Enter your IFSC Code---");
			IFSCcode=scan.next();
			biserv.validationIfsc(IFSCcode);
			}while(biserv.h==false);
			System.out.println("-----Enter your Branch---");
			branch=scan.next();
			do
			{
			System.out.println("-----Enter your Mail Id---");
			mail=scan.next();
			biserv.validateMail(mail);
			}while(biserv.h==false);
			System.out.println("-----Set UserId ---");
			userId=scan.next();
			do
			{
			System.out.println("-----Create Password---");
			String password1=scan.next();
			System.out.println("-----Enter Password Again For Confirmation---");
			
			do
			{
			String password2=scan.next();
			if(password1.equals(password2))
			{
				System.out.println("Password is matched");
				password=password1;
				break;
			}
			else
			{
				System.out.println("------Password  is not matching------- ");
				System.out.println("----Enter again-----");
				 b=false;
			}
			}while(b==false);
			biserv.validatepassword(password);
			}while(biserv.h==false);
			do
			{
			System.out.println("-----Enter Opening Balance Amount---");
			openingBalance=scan.nextInt();
			biserv.validationAccBalance(openingBalance);
			}while(biserv.h==false);
			BankingBean ban=new BankingBean(openingBalance,name,mobile,panNumber,
					IFSCcode,branch,mail,userId,password);
			BankingTransactionBean transaction = new BankingTransactionBean( );
			transaction.setTransactionAmount(openingBalance);
			transaction.setAccountBalance(openingBalance);
			transaction.setTypeOfTransaction("create Account");
			ibserv= new BankingImplService();
			int aid=ibserv.createAccount(ban, transaction);	
			return aid;			
		}
		public static int showBalance(int accountNumber)
		{
			ibserv= new BankingImplService();
			int aid1=ibserv.showBalance(accountNumber);
			return aid1;
		}
		public static int deposit(int accountNumber,int depositAmount)
		{
			BankingTransactionBean transaction = new BankingTransactionBean( );
			ibserv= new BankingImplService();
		int finalAmount=ibserv.deposit(accountNumber ,depositAmount,transaction);
		transaction.setTransactionAmount(depositAmount);
		transaction.setAccountBalance(finalAmount);
		transaction.setTypeOfTransaction("Deposit");
		return finalAmount;
			
		}
		public static int withdraw(int accountNumber,int withdrawnAmount)
		{
			BankingTransactionBean transaction = new BankingTransactionBean( );
			ibserv= new BankingImplService();
			int balanceAmount=ibserv.withdraw(accountNumber, withdrawnAmount,transaction);
			transaction.setTransactionAmount(withdrawnAmount);
			transaction.setAccountBalance(balanceAmount);
			transaction.setTypeOfTransaction("Withdraw");
			return balanceAmount;
		}
		public static void fundTransfer()
		{
			int fromAccountNumber;
			int toAccountNumber;
			int amount;
			String userId="";
			String password = "";
			System.out.println("----enter your account number----");
			fromAccountNumber=scan.nextInt();
			System.out.println("----enter to account number----");
			toAccountNumber=scan.nextInt();
			System.out.println("----enter amount to be transfer----");
			amount=scan.nextInt();
			System.out.println("---enter user id----");
			userId=scan.next();
			System.out.println("----enter password---");
			password=scan.next();
			BankingTransactionBean transaction = new BankingTransactionBean( );
			ibserv= new BankingImplService();
			int remainingBalance=ibserv.fundTransfer( fromAccountNumber, toAccountNumber,
					amount,userId,password,transaction);
			System.out.println("---Transfered Successfully----");
			System.out.println("remaining balance is : "+remainingBalance+
					" after transfering amount: "+amount );
			transaction.setTransactionAmount(amount);
			transaction.setAccountBalance(remainingBalance);
			transaction.setTypeOfTransaction("Fund Transefered");
			
		}
		public static void printTransactions()
		{
			
			ibserv= new BankingImplService();
			HashMap<Integer, BankingTransactionBean> transaction = ibserv.printTransactions();
			int accountNumber;
			System.out.println("----------------enter account number to view transaction details-------------");
			accountNumber=scan.nextInt();
			Collection<BankingTransactionBean> transactions = transaction.values();
			for(BankingTransactionBean trans:transactions){
				if(trans.getAccountNumber()==accountNumber){
					System.out.println(trans);
				}
			}
		}
}
