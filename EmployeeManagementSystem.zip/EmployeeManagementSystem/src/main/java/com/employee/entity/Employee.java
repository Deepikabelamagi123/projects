package com.employee.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Employee")

public class Employee 
{
	 @Column(name="EMP_ID")
	 @Id
	 @GeneratedValue(strategy=GenerationType.AUTO)
	 private Integer emp_id;

	 @Column(name="NAME",nullable=true,length=200)
	 private String name;


	 @Column(name="DESIGNATION",nullable=true,length=200)
	 private String designation;

	 @Column(name="DEPT_NAME",nullable=true,length=200)
	 private String dept_name;

	 @Column(name="SALARY",nullable=true,length=50)
	 private int salary;

	public Employee(String name, String designation, String dept_name, int salary) {
		super();
		this.name = name;
		this.designation = designation;
		this.dept_name = dept_name;
		this.salary = salary;
	}
	
	public Employee()
	{
		
	}

	public Integer getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(Integer emp_id) {
		this.emp_id = emp_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getDept_name() {
		return dept_name;
	}

	public void setDept_name(String dept_name) {
		this.dept_name = dept_name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [emp_id=" + emp_id + ", name=" + name + ", designation=" + designation + ", dept_name="
				+ dept_name + ", salary=" + salary + "]";
	}

	
}
