package com.cg.feedback.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.feedback.entities.Feedback;
import com.cg.feedback.services.FeedbackCommonService;

@RestController

@RequestMapping("/feedback")
@CrossOrigin(origins="*",allowedHeaders="*")
public class FeedbackCommonController {
		@Autowired private FeedbackCommonService service;
	
		//Test URL: http://localhost:8080/feedback/feedback
	@PostMapping(value="/feedback",produces= {"application/xml","application/json"})
	public ResponseEntity<String> getComments(@RequestBody Feedback f){
		
		System.out.println("Sending feedback to the CapStore");
		service.getcomments(f);
		return new ResponseEntity<String>("Feedback was sent successfully....",HttpStatus.CREATED) ;
		
	}
	
	
	//Test URL: http://localhost:8080/feedback/Adminvisit
	 @GetMapping("/Adminvisit")
	 public List<Feedback> forwardToMerchant(){
			System.out.println("All the CapStore feedbacks");
			  List<Feedback> fb= service.forwardToMerchant();
			  System.out.println(fb);
			 return fb;
	 }
	 
	 
	//Test URL: http://localhost:8080/feedback/response
	 @PutMapping(value="/response",	produces= {"application/xml","application/json"})
		public ResponseEntity<String> fromMerchant(@RequestBody Feedback f){
		 System.out.println("Sending response to Customer");
		service.findById(f.getId());
		 service.responseFromMerchant(f);
			return new ResponseEntity<String>("Response was sent successfully....".toString(),HttpStatus.OK);
			
		}
}
