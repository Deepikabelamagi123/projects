package com.cg.feedback.dao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.feedback.entities.Feedback;

@Repository

public interface feedbackDAO extends JpaRepository<Feedback, Integer> {

	
	


}
