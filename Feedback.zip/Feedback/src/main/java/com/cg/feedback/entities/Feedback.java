package com.cg.feedback.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

//Bean Class
@Entity
@Table(name="feedbacks")
@XmlRootElement
public class Feedback {

	@Column(name="fid", length=300)
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer fid;
	
	@Column(name="comments", length=300)
	private String comment;
	
	//@Column(name="pid", length=300)
	//private String id;
	
	@Column(name="pname", length=30)
	private String Product_name;
	
	@Column(name="ratings")
	private Integer rating;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="start_time")
	private Date start_time;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="end_time")
	private Date end_time;
	
	public Date getStart_time() {
		return start_time;
	}

	public void setStart_time(Date start_time) {
		this.start_time = start_time;
	}

	public Date getEnd_time() {
		return end_time;
	}

	public void setEnd_time(Date end_time) {
		this.end_time = end_time;
	}

	public Integer getId() {
		return fid;
	}

	public void setId(Integer fid) {
		this.fid = fid;
}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	
	
	
	public Feedback( String comment, String product_name, Integer rating, Date start_time, Date end_time) {
		super();
	   
		this.comment = comment;
		Product_name = product_name;
		this.rating = rating;
		this.start_time = start_time;
		this.end_time = end_time;
	}

	public String getProduct_name() {
		return Product_name;
	}

	public void setProduct_name(String product_name) {
		Product_name = product_name;
	}

	public Feedback() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Feedback [fid=" + fid + ", comment=" + comment + ", Product_name=" + Product_name + ", rating=" + rating
				+ ", start_time=" + start_time + ", end_time=" + end_time + "]";
	}

	

	
	
	
}
