package com.cg.feedback.exceptions;

public class InvalidFeedbackException extends RuntimeException {

	public InvalidFeedbackException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidFeedbackException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}