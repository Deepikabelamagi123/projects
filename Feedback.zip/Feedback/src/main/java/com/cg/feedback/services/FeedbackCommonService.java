package com.cg.feedback.services;

import java.util.List;
import java.util.Optional;

import com.cg.feedback.entities.Feedback;

public interface FeedbackCommonService {

	
	void getcomments(Feedback f);
	List<Feedback> forwardToMerchant();
	Object findById(Integer id);
	void responseFromMerchant(Feedback f);
}
