package com.cg.feedback.services;

import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.feedback.dao.feedbackDAO;
import com.cg.feedback.entities.Feedback;
import com.cg.feedback.exceptions.InvalidFeedbackException;


@Service
@Transactional
public class FeedbackCommonServiceImpl implements FeedbackCommonService {

	
	@Autowired private feedbackDAO dao;
	
	@Transactional
	public void getcomments(Feedback f) {
		
		dao.save(f);
		
	}

	@Transactional
	public List<Feedback> forwardToMerchant() {
		return dao.findAll();
		

	}

	@Transactional
	public void responseFromMerchant(Feedback f) {
		
		System.out.println(f.getId());
		
        dao.save(f);
       
}



	@Override
	public Feedback findById(Integer fid) {
		
		
		return dao.findById(fid).get();
	}

}
