package com.bankapplication.bean;

public class BankBean 
{
	String name;
	String mobileNum;
	String alternateMobileNum;
	String email;
	String address;
	String panNum;
	int accountNum;
	int amount;
	//String date;
	
	public BankBean()
	{
		
	}
	
	
	
	public BankBean(String name, String mobileNum, String alternateMobileNum,
			String email, String address, String panNum,int amount) 
	{
		super();
		this.name = name;
		this.mobileNum = mobileNum;
		this.alternateMobileNum = alternateMobileNum;
		this.email = email;
		this.address = address;
		this.panNum = panNum;
		this.amount=amount;
		//this.date=
	}

	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNum() {
		return mobileNum;
	}

	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}

	public String getAlternateMobileNum() {
		return alternateMobileNum;
	}

	public void setAlternateMobileNum(String alternateMobileNum) {
		this.alternateMobileNum = alternateMobileNum;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPanNum() {
		return panNum;
	}

	public void setPanNum(String panNum) {
		this.panNum = panNum;
	}

	public int getAccountNum() {
		return accountNum;
	}

	public void setAccountNum(int accountNum) {
		this.accountNum = accountNum;
	}
	

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	
	@Override
	public String toString() {
		return "BankBean [name=" + name + ", mobileNum=" + mobileNum
				+ ", alternateMobileNum=" + alternateMobileNum + ", email="
				+ email + ", address=" + address + ", panNum=" + panNum
				+ ", accountNum=" + accountNum +", amount=" + amount+ "]";
	}

	
	
}
