package com.bankapplication.bean;

public class TransactionBean 
{
	int accountNum;
	int transactionId;
	String typeOfTransaction;
	double balance;
	double transactionAmount;
	
	public TransactionBean ()
	{
		
	}

	public TransactionBean(int accId, String typeOfTransaction, double balance,
			double transactionAmount) {
		super();
		this.accountNum = accId;
		this.typeOfTransaction = typeOfTransaction;
		this.balance = balance;
		this.transactionAmount = transactionAmount;
	}

	public int getAccountNum() {
		return accountNum;
	}

	public void setAccountNum(int AccountNum) {
		this.accountNum = AccountNum;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTypeOfTransaction() {
		return typeOfTransaction;
	}

	public void setTypeOfTransaction(String typeOfTransaction) {
		this.typeOfTransaction = typeOfTransaction;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	@Override
	public String toString() {
		return "TransactionBean [AccountNum=" + accountNum + ", transactionId="
				+ transactionId + ", typeOfTransaction=" + typeOfTransaction
				+ ", balance=" + balance + ", transactionAmount="
				+ transactionAmount + "]";
	}
	
	
}
