package com.bankapplication.dao;


import java.util.Collection;
import java.util.HashMap;

import com.bankapplication.bean.BankBean;
import com.bankapplication.bean.TransactionBean;
import com.bankapplication.exception.InvalidNumException;


public class BankDaoImpl implements IBankDao

{
	//static int newBal;
	static HashMap<Integer,BankBean> bankList=new HashMap<>();
	static BankBean bBean=new BankBean();
	static HashMap<Integer,TransactionBean> transactionList=new HashMap<>();
	static TransactionBean tBean=new TransactionBean();
	@Override
	public int createAccount(BankBean b,TransactionBean t)
	{
		bankList.put(b.getAccountNum(), b);
		System.out.println(bankList);
		
	
		transactionList.put(t.getTransactionId(),t);
		return b.getAccountNum();
		
		
	}
	
	public void showBalance(int accnum)
	{
		BankBean c1=bankList.get(accnum);
		System.out.println(c1.getAmount());
	}

	@Override
	public int deposit(int accnum, int amt,TransactionBean t)
	{
		BankBean c7=bankList.get(accnum);
		
		
		
		if (c7!=null)
		{
		//int finalAmount=c1.getAmount()+amt;
		//c1.setAmount(finalAmount);
		int newBal=(c7.getAmount()+amt);
		c7.setAmount(newBal);
		transactionList.put(t.getTransactionId(), t);
		}
		return c7.getAmount();

		
		
		
		
			
	}
	@Override
	public int withdraw(int accnum, int amt1,TransactionBean t)
	{
		BankBean c2=bankList.get(accnum);
		
		
		if(c2!=null)
		{
			if(c2.getAmount()>amt1)
			{
				int newBal1=(c2.getAmount()-amt1);
				System.out.println(newBal1);
				c2.setAmount(newBal1);
				
				transactionList.put(t.getTransactionId(), t);
			}
		}
		
		return c2.getAmount();
		

		
		
		
	}

	@Override
	public HashMap<Integer, TransactionBean> printTransaction()
	{
		HashMap<Integer,TransactionBean> t = (HashMap<Integer,TransactionBean>) transactionList;
		return t;
	}
	

	@Override
	public int fundTransfer(int accnum, int accnum1, int amt,TransactionBean t) 
	{
		BankBean c4=bankList.get(accnum);
		BankBean c5=bankList.get(accnum1);
		
		
		//System.out.println(c5.getAmount());
		
		
		//BankingBean ban1=accountlist.get(fromAccountNumber);
		//BankingBean ban2=accountlist.get(toAccountNumber);
		if(c4!=null&&c5!=null)
		{
			//if(userId.equals(ban1.getUserId())&&password.equals(ban1.getPassword()))
			//{
				
				int amt1=c4.getAmount()-amt;
				c4.setAmount(amt1);
				int amt2=c5.getAmount()+amt;
				c5.setAmount(amt2);
				//System.out.println(c4.getAmount());
			
			tBean.setTypeOfTransaction("Funds Transfered");
			transactionList.put(t.getTransactionId(), t);
			return c4.getAmount();
			}
			else
			{
				return 0;
			}
		}
		
		
	


		
		
	}

	
	

