package com.bankapplication.dao;

import java.util.HashMap;

import com.bankapplication.bean.BankBean;
import com.bankapplication.bean.TransactionBean;
import com.bankapplication.exception.InValidNameException;
import com.bankapplication.exception.InvalidNumException;

public interface IBankDao 
{
	public int createAccount(BankBean b,TransactionBean t);
	public void showBalance(int accnum);
	public int deposit(int accnum, int amt,TransactionBean t);
	public int withdraw(int accnum, int amt,TransactionBean t);
	public HashMap<Integer,TransactionBean> printTransaction();
	
	//public HashMap<Integer, BankingTransactionBean> printTransactions();


	public int fundTransfer(int accnum,int accnum1,int amt,TransactionBean t);

}
