package com.bankapplication.exception;

public class InValidEmailException extends Exception {

	public InValidEmailException(String string) {
		super(string);
	}

}
