package com.bankapplication.exception;

public class InValidNameException extends Exception
{

	public InValidNameException(String string) {
		super(string);

}
}