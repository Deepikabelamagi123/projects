package com.bankapplication.exception;

public class InvalidNumException extends Exception {

	public InvalidNumException(String string) {
		super(string);
	}

}
