package com.bankapplication.exception;

public class InvalidPanException extends Exception {

	public InvalidPanException(String string) {
	super(string);
	}

}
