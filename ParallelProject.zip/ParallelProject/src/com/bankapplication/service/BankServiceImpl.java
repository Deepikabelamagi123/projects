package com.bankapplication.service;

import java.util.HashMap;
import java.util.Random;
import java.util.regex.Pattern;

import com.bankapplication.bean.BankBean;
import com.bankapplication.bean.TransactionBean;
import com.bankapplication.dao.BankDaoImpl;
import com.bankapplication.dao.IBankDao;
import com.bankapplication.exception.InValidEmailException;
import com.bankapplication.exception.InValidNameException;
import com.bankapplication.exception.InvalidNumException;
import com.bankapplication.exception.InvalidPanException;


public class BankServiceImpl  implements  IBankService
{	
	static IBankDao idao=null;
	static TransactionBean b=new TransactionBean();

	
	private int generateAccountNum()
	{
		Random r=new Random();
		return r.nextInt(100000);
	}
	private int generateTransactionId()
	{
		Random r=new Random();
		return r.nextInt(10000);
	}
	
	
	public int createAccount(BankBean b, TransactionBean t)
	{
		idao=new BankDaoImpl();
		 b.setAccountNum(generateAccountNum());
		 t.setAccountNum(b.getAccountNum());
		 t.setTransactionId(generateTransactionId());
		 
		 return idao.createAccount(b,t);
		 
	}
	
	public void showBalance(int accnum)
	{
		idao.showBalance(accnum);
	}

	@Override
	public boolean validateName(String name) throws InValidNameException
	{
		if(!Pattern.compile("^[A-Z]([a-z]){5,}").matcher(name).find()){
			
			throw new InValidNameException("invalid name ");}
		
		return true;
	}
	
	public boolean validateMobileNum(String num) throws InvalidNumException
	{
		if(!Pattern.compile("^[6-9][0-9]{9}").matcher(num).find())
		{
			
			throw new InvalidNumException("invalid num");
		}
		
		return true;
	}
		
	public boolean validateEmail(String email) throws InValidEmailException
	{
		if(!Pattern.compile("^[a-z0-9]{1,}@gmail.com").matcher(email).find())
		{
			
			throw new InValidEmailException("invalid email id");
		}
		
		return true;
	}
	public boolean validatePan(String pan) throws InvalidPanException
	{
		if(!Pattern.compile("^[A-Z]{5}[0-9]{5}").matcher(pan).find())
		{
			
			throw new InvalidPanException("invalid pan");
		}
		
		return true;
	}
	
	public boolean validateAmount(int amount) throws InvalidPanException
	{
		if(amount<1000)
		{
			
			throw new InvalidPanException(" amount  is less than minimum balance");
		}
		
		return true;
	}
	
	@Override
	public int deposit(int accnum, int amt,TransactionBean t)
	{
		idao=new BankDaoImpl();
		t.setTransactionId(generateTransactionId());
		t.setAccountNum(accnum);
		return idao.deposit(accnum,amt,t);
	}
	
	@Override
	public int withdraw(int accnum, int amt,TransactionBean t) 
	{	
		idao=new BankDaoImpl();
		

		
		//iband=new BankingImplDao();
		t.setTransactionId(generateTransactionId());
		t.setAccountNum(accnum);
		return idao.withdraw(accnum,amt,t);
		
		
	}
	@Override
       public HashMap<Integer, TransactionBean> printTransaction() {
		
		
		//iband=new BankingImplDao();
		idao=new BankDaoImpl();
		
		return idao.printTransaction();		
	}

	@Override
	public int fundTransfer(int accnum, int accnum1, int amt,TransactionBean t) 
	{
		
		
		idao=new BankDaoImpl();
		
		//iband=new BankingImplDao();
		t.setTransactionId(generateTransactionId());
		t.setAccountNum(accnum);
		return	idao.fundTransfer(accnum,accnum1,amt,t);
		

		
	}
		
}	
		
		
	


