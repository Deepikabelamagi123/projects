package com.bankapplication.service;

import java.util.HashMap;

import com.bankapplication.bean.BankBean;
import com.bankapplication.bean.TransactionBean;
import com.bankapplication.exception.InValidEmailException;
import com.bankapplication.exception.InValidNameException;
import com.bankapplication.exception.InvalidNumException;
import com.bankapplication.exception.InvalidPanException;

public interface IBankService 
{
	public int createAccount(BankBean b,TransactionBean t);
	public void showBalance(int accnum);
	public int deposit(int accnum ,int amt,TransactionBean t);
	public int withdraw(int accnum ,int amt,TransactionBean t);
	 public HashMap<Integer, TransactionBean> printTransaction();
	public int fundTransfer(int accnum,int accnum1,int amt,TransactionBean t);

	public boolean validateName(String name) throws InValidNameException;
	public boolean validateMobileNum(String mobileNum) throws InvalidNumException;
	public boolean validateEmail(String email) throws InValidEmailException;
	public boolean validatePan(String panNum) throws  InvalidPanException;
	public boolean validateAmount(int amount) throws InvalidPanException;
	
}
