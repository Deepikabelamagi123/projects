package com.bankapplication.test;


import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.bankapplication.bean.BankBean;
import com.bankapplication.dao.BankDaoImpl;
import com.bankapplication.dao.IBankDao;


public class TestCase 
{
	static IBankDao idao= null;
	@Before
	public  void setup()
	{
		idao=new BankDaoImpl();
	}
	@After
	public  void teardown()
	{
		idao=null;
	}
	//@SuppressWarnings("deprecation")
	@Test
	public void test() 
	{
		BankBean b=new BankBean("Deepika","9620999654","9620333094","deepu@gmail.com","vijaypur","DFGH458",5000);
		b.setAccountNum(2000);
		Assert.assertEquals(2000,b.getAccountNum());
		//Assert.assertNotNull(b);
		
		
	}

}
