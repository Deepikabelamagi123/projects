package com.bankapplication.ui;

import java.time.LocalDate;
import java.util.Collection;
import java.util.HashMap;
import java.util.Scanner;

import com.bankapplication.bean.BankBean;
import com.bankapplication.bean.TransactionBean;
import com.bankapplication.exception.InValidEmailException;
import com.bankapplication.exception.InValidNameException;
import com.bankapplication.exception.InvalidNumException;
import com.bankapplication.exception.InvalidPanException;
import com.bankapplication.service.BankServiceImpl;
import com.bankapplication.service.IBankService;


public class BankUI
{	
	static IBankService iserv=null;
	static Scanner scan=new Scanner(System.in);
	static String a;
	static boolean res=true;
	static int accnum;
	static int amount;
	
	public static void main(String[] args)
	{
				
		do{
			System.out.println("1. createAccount \n 2.Show balance \n 3. Deposit\n 4.Withdraw \n5.Fund trnasfer\n 6.print Transaction");
			
			switch(scan.nextInt())
			{
			case 1:
				int id=createAccount();
				System.out.println("your account is created successfully on:"+LocalDate.now());
				System.out.println("your account num is :"+id);
				break;
				
			case 2:
				System.out.println("enter account num to view balance");
				 accnum=scan.nextInt();
				System.out.println("available balance:"+LocalDate.now());
				showBalance(accnum);
				break;
				
			case 3:
				System.out.println("enter your account num");
				accnum=scan.nextInt();
				System.out.println("enter amount to deposit");
				 amount=scan.nextInt();
				System.out.println("transction done successfully");
				System.out.println("RS"+amount+" is credited to your account on:"+LocalDate.now());
				System.out.println("avilable bal:");
				deposit(accnum,amount);
				break;
			
			case 4:
				System.out.println("enter your account num");
				accnum=scan.nextInt();
				System.out.println("enter amount to withdraw");
				 amount=scan.nextInt();
				System.out.println("transction done successfully");
				System.out.println("RS"+amount+" is debited from your account on:"+LocalDate.now());
				System.out.println("avilable bal:");
				withdraw(accnum,amount);
				break;
				
			case 5:
				System.out.println("enter accnum from which u need to transfer");
				accnum=scan.nextInt();
				System.out.println("enter accnum to which u need to transfer");
				int accnum1=scan.nextInt();
				System.out.println("enter amt need to be transfer");
				amount=scan.nextInt();
				System.out.println("RS"+amount+" is debited from your account on:"+LocalDate.now());
				System.out.println("after transfer available bal:");
				//System.out.println("balance of credited account:");
				fundTransfer(accnum,accnum1,amount);
				
				break;
			case 6:
				//System.out.println("enter account number");
				//accnum=scan.nextInt();
				printTransaction();
			
				
			default:
				break;
			}
			System.out.println("do you wann continue y/n");
			 a=scan.next();
			
		}while(a.equals("y"));
		
	}
	
	
	private static int createAccount()
	{
		iserv=new BankServiceImpl();
		
		String name=null;
		String mobileNum=null;
		String alternateMobileNum=null;
		String email=null;
		String address=null;
		String panNum=null;
		int accountNum=0;
		int amount=0;
		
		int accId=0;
		String typeOfTransaction=null;
		double balance=0;
		double transactionAmount=0;
		
		
		
		
		
		res=false;
		do {
			try {
				System.out.println("enter your  name");
				 name = scan.next();
				res = iserv.validateName(name);
			} catch (InValidNameException e) {
				System.out.println("enter proper name");
			}
		} while(!res);
		
		res=false;
		
		do {
			try {
				System.out.println("enter your mobile num");
				mobileNum=scan.next();
				
				res = iserv.validateMobileNum(mobileNum);
			} catch (InvalidNumException e) {
				System.out.println("enter valid number");
			}
		} while(!res);
		res=false;
		do {
			try {
				System.out.println("enter your alternate mobile num");
				alternateMobileNum=scan.next();
				
				res = iserv.validateMobileNum(alternateMobileNum);
			} catch (InvalidNumException e) {
				System.out.println("enter valid number");
			}
		} while(!res);
		res=false;
		do {
			try {
				System.out.println("enter your emai id ");
				email=scan.next();
				res = iserv.validateEmail(email);
			} catch (InValidEmailException e) {
				System.out.println("enter valid email");
			}
		} while(!res);
		res=false;
		do {
			try {
				System.out.println("enter your pan num");
				panNum=scan.next();
				
				res = iserv.validatePan(panNum);
			} catch (InvalidPanException e) {
				System.out.println("enter valid pan num");
			}
		} while(!res);
		res=false;
		
		do {
			try {
				System.out.println("enter amount to maintain minimum balance:");
				amount=scan.nextInt();
				
				
				res = iserv.validateAmount(amount);
			} catch (InvalidPanException e) {
				System.out.println("enter minimum amount to open account");
			}
		} while(!res);
		
		res=false;
		System.out.println("enter your Address ");
		address=scan.next();
		
	BankBean b=new BankBean(name,mobileNum,alternateMobileNum,email,address,panNum,amount);
	iserv=new BankServiceImpl();
	
	//TransactionBean t=new TransactionBean(accId,typeOfTransaction, balance,transactionAmount); 
	TransactionBean t=new TransactionBean(); 
	
	//BankingTransactionBean transaction = new BankingTransactionBean( );
	t.setTransactionAmount(amount);
	t.setBalance(amount);
	t.setTypeOfTransaction("create Account");
	iserv=new BankServiceImpl();
	int aid=iserv.createAccount(b, t);	
	return aid;			
}
	
	
	public static void showBalance(int accnum)
	{
		iserv.showBalance(accnum);
	}
	
	public static void deposit(int accnum,int amt)
	{
		

		TransactionBean t=new TransactionBean(); 
		iserv=new BankServiceImpl();
	    int finalAmount=iserv.deposit(accnum ,amt,t);
	    t.setTransactionAmount(amt);
	    t.setBalance(finalAmount);
	    t.setTypeOfTransaction("Deposit");
	
	     System.out.println(finalAmount);
	
		
	}

		public static int withdraw(int accnum,int amt)
	{
		
		TransactionBean t=new TransactionBean(); 
		iserv=new BankServiceImpl();
		
		int balanceAmount=iserv.withdraw(accnum, amt,t);
		t.setTransactionAmount(amt);
		t.setBalance(balanceAmount);
		t.setTypeOfTransaction("Withdraw");
		return balanceAmount;

		
		
		
	}
	public static void printTransaction()
	{
		
		TransactionBean t=new TransactionBean(); 
		iserv=new BankServiceImpl();
		
		HashMap<Integer,TransactionBean> transaction = iserv.printTransaction();
		int accountNumber;
		System.out.println("----------------enter account number to view transaction details-------------");
		accountNumber=scan.nextInt();
		
		Collection<TransactionBean> transactions = transaction.values();
		for(TransactionBean trans:transactions){
			if(trans.getAccountNum()==accountNumber)
			{
				System.out.println(trans);
			}
		}
		}
	public static void fundTransfer(int accnum,int accnum1,int amt)
	{
		
		TransactionBean t=new TransactionBean(); 
		iserv=new BankServiceImpl();
		int remainingBalance=iserv.fundTransfer( accnum, accnum1,amt,t);
		System.out.println("---Transfered Successfully----");
		System.out.println("remaining balance is : "+remainingBalance+
				" after transfering amount: "+amount );
		t.setTransactionAmount(amount);
		t.setBalance(remainingBalance);
		t.setTypeOfTransaction("Fund Transefered");

		
		
	}
}	


