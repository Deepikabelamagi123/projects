package com.demo.controller;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.demo.entity.Account;
import com.demo.service.AccountService;



@RestController
@RequestMapping("/account")

public class UserController

{
 @Autowired
AccountService accountService;



 @RequestMapping(value = "/all", method = RequestMethod.GET)
public List<Account> getAllUsers() {
return this.accountService.getAlldetails();

 }

 @RequestMapping(value = "/addcustomer", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
public Account addAccount(@RequestBody Account account) {
return this.accountService.addUser(account);

 }



 @RequestMapping(value = "/deposit", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
public Account deposit(@RequestBody Account account) {
return this.accountService.deposit(account);

 }



 @RequestMapping(value = "/withdraw", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
public Account withdraw(@RequestBody Account account) {
return this.accountService.withdraw(account);

 }
 
 
 @RequestMapping(value = "/{id}", method = RequestMethod.GET)
public Optional<Account> getAccountById(@PathVariable int id) {
   return this.accountService.getAccountById(id);
}




}

