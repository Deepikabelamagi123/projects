package com.demo.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="Account")

public class Account
{

 @Column(name="AccountNumber")
 @Id
 @GeneratedValue(strategy=GenerationType.AUTO)
 private Integer accountId;

 @Column(name="acc_holderName",nullable=true,length=20)
 private String name;


 @Column(name="EmailId",nullable=true,length=25)
 private String emailId;

 @Column(name="PhoneNo",nullable=true,length=25)
 private String phoneNo;

 @Column(name="Balance",nullable=true,length=25)
 private int balance;



 //parameterized constructor

 public Account( String name, String emailId, String phoneNo, int balance) {
 super();

 this.name = name;
 this.emailId = emailId;
 this.phoneNo = phoneNo;
 this.balance = balance;

 }

//default constructor

 public Account()
 {
 super();
 }



 //getter and setter method

 public Integer getId()  {
 return accountId;
 }



 public void setId(Integer id) {
 this.accountId = id;
 }



 public String getName() {
 return name;
 }



 public void setName(String name) {
 this.name = name;
 }



 public String getEmailId() {
 return emailId;
 }



 public void setEmailId(String emailId) {
 this.emailId = emailId;
 }



 public String getPhoneNo() {
 return phoneNo;
 }



 public void setPhoneNo(String phoneNo) {
 this.phoneNo = phoneNo;
 }



 public int getBalance() {
 return balance;
 }



 public void setBalance(int balance) {
 this.balance = balance;
 }



 //to string method

 @Override
 public String toString() {
 return "User [accountId=" + accountId + ", name=" + name + ", emailId=" + emailId + ", phoneNo=" + phoneNo + ", balance="
  + balance + "]";
 }
}

