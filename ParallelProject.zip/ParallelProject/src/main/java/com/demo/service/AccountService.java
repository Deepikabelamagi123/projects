package com.demo.service;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.demo.dao.AccountDao;
import com.demo.entity.Account;

@Service
public class AccountService
{
@Autowired
AccountDao accountDao;

public List<Account> getAlldetails() {
return this.accountDao.findAll();

}



public Account addUser(Account account) {
return this.accountDao.save(account);

}



public Account deposit(Account account) {
return this.accountDao.save(account);

}



public Account withdraw(Account account) {
 return this.accountDao.save(account);

}

 
public Optional<Account> getAccountById(int accId) {
    return this.accountDao.findById(accId);
} 
  
 






}