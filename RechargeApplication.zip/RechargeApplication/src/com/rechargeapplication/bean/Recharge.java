package com.rechargeapplication.bean;

public class Recharge
{
	String name;
	String mob;
	String description;
	String rechargeType;
	String planName;
	String date;
	int Rid;
	double amt;
	
	Recharge()
	{
		
	}

	public Recharge(String name, String mob, String description,double amt,
			String rechargeType, String planName
			) {
		//super();
		this.name = name;
		this.mob = mob;
		this.description = description;
		this.rechargeType = rechargeType;
		this.planName = planName;
		this.date = date;
		this.Rid = Rid;
		this.amt = amt;
		}

	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMob() {
		return mob;
	}

	public void setMob(String mob) {
		this.mob = mob;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getRechargeType() {
		return rechargeType;
	}

	public void setRechargeType(String rechargeType) {
		this.rechargeType = rechargeType;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getRid() {
		return Rid;
	}

	public void setRid(int rid) {
		Rid = rid;
	}

	public double getAmt() {
		return amt;
	}

	public void setAmt(double amt) {
		this.amt = amt;
	}
	

	@Override
	public String toString() {
		return "Recharge [name=" + name + ", mob=" + mob + ", description="
				+ description + ", rechargeType=" + rechargeType
				+ ", planName=" + planName + ", amt=" + amt + "]";
	}


}
