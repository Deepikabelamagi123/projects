package com.rechargeapplication.dao;

import com.rechargeapplication.bean.Recharge;

public interface IRechargeDao
{
	public int AddRecharge(Recharge rc);
	
	public void viewAllTransction();
	public void viewByTid(int Rid);
	public void update(int Rid ,String name);
	public void delete(int Rid);
	
	
}
