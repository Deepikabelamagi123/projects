package com.rechargeapplication.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.rechargeapplication.bean.Recharge;


public class RechargeDaoImp implements IRechargeDao
{
	static Map<Integer,Recharge> RechargeList=new HashMap<Integer,Recharge>();

	@Override
	public int AddRecharge(Recharge rc) {
		RechargeList.put(rc.getRid(), rc);
		System.out.println(RechargeList);
		return rc.getRid();
	}

	@Override
	public void viewAllTransction() {
		Collection<Recharge> c=RechargeList.values();
		System.out.println(c);
		for(Recharge rc:c)
		{
			System.out.println(rc.getName());
			System.out.println(rc.getRid());
		}
	}

	@Override
	public void viewByTid(int Rid) {
		Recharge c1=RechargeList.get(Rid);
		System.out.println(c1);
		
			System.out.println(c1.getName());
			System.out.println(c1.getRid());
		
		
	}

	@Override
	public void update(int Rid ,String name) 
	{
		Recharge rc=RechargeList.get(Rid);
		rc.setName(name);
	
		
	}

	@Override
	public void delete(int Rid) {
		Collection<Recharge> c=RechargeList.values();
		RechargeList.remove(Rid);
	}
	
	
}
