package com.rechargeapplication.exception;

public class InvalidNameException extends Exception {

	public InvalidNameException(String string)
	{
		super(string);
	}
	
	public InvalidNameException()
	{
		super();
	}
}
