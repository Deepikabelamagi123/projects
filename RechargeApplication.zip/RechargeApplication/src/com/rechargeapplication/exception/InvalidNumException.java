package com.rechargeapplication.exception;

public class InvalidNumException extends Exception {

	public InvalidNumException(String string) {
		super(string);
	}
	public InvalidNumException (){
		super();
	}

}
