package com.rechargeapplication.exception;

public class InvalidPlanException extends Exception {

	public InvalidPlanException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}

	public InvalidPlanException() {
		// TODO Auto-generated constructor stub
		super();
	}
}
