package com.rechargeapplication.service;

import com.rechargeapplication.bean.Recharge;
import com.rechargeapplication.exception.InvalidNameException;
import com.rechargeapplication.exception.InvalidNumException;
import com.rechargeapplication.exception.InvalidPlanException;



public interface IRechargeService
{
	public int AddRecharge(Recharge rc);
	public void viewAllTransction();
	public void viewByTid(int Rid);
	public void update(int Rid, String name);
	public void delete(int Rid);
	public boolean validateName(String name) throws InvalidNameException;
	public boolean validateNum(String mob) throws InvalidNumException;
	
	public boolean validatePlanType(String plantype) throws InvalidPlanException;

}	

	
