package com.rechargeapplication.service;

import java.util.Random;
import java.util.regex.Pattern;




import com.rechargeapplication.bean.Recharge;
import com.rechargeapplication.dao.IRechargeDao;
import com.rechargeapplication.dao.RechargeDaoImp;
import com.rechargeapplication.exception.InvalidNameException;
import com.rechargeapplication.exception.InvalidNumException;
import com.rechargeapplication.exception.InvalidPlanException;

public class RechargeServiceImp implements IRechargeService
{
	IRechargeDao idao=null;
	
	private int generateReachargeId()
	{
		Random r=new Random();
		return r.nextInt(10000);
	}

	@Override
	public int AddRecharge(Recharge rc) {
		rc.setRid(generateReachargeId());
		idao=new RechargeDaoImp();
		return idao.AddRecharge(rc);
	}

	@Override
	public void viewAllTransction() {
		idao.viewAllTransction();
		
	}

	@Override
	public void viewByTid(int Rid) {
		idao.viewByTid(Rid);
	}

	@Override
	public void update(int Rid ,String name) {
		idao.update(Rid, name);
		
	}

	@Override
	public void delete(int Rid) {
		idao.delete(Rid);
		
	}
	
	public boolean validateName(String name) throws InvalidNameException
	{
		if(!Pattern.compile("^[A-Z]([a-z]){5,}").matcher(name).find())
		{
		throw new InvalidNameException("not matching pattern");
		}
		return true;
	}
	
	
	public boolean validateNum(String num) throws InvalidNumException
	{
		if(!Pattern.compile("^[6-9][0-9]{9}").matcher(num).find())
		{
			throw new InvalidNumException("invalid number");
		}
			return true;
	}
	
	public boolean validatePlanType(String plan) throws InvalidPlanException
	{

		if(!Pattern.compile("(prepaid|postpaid)").matcher(plan).find())
		{
		throw new InvalidPlanException("invalid plan");
		}
		return true;
		
		
		
		}
}
	


	

