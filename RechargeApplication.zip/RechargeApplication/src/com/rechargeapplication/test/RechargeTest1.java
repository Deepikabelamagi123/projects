package com.rechargeapplication.test;

import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.rechargeapplication.bean.Recharge;
import com.rechargeapplication.dao.IRechargeDao;
import com.rechargeapplication.dao.RechargeDaoImp;

public class RechargeTest1 
{
	IRechargeDao idao=null;
	@Before
	public void setup()
	{
		idao=new RechargeDaoImp();
	}
	@After
	public void teardown()
	{
		idao=null;
	}
	@Test
	public void test() 
	{
		Recharge rc=new Recharge("Deepika","9620333094","30days",30000,"30DAYS","postpaid");
		rc.setRid(40000);
		Assert.assertEquals(rc.getRid(), 40000);
		
	}
	
}
