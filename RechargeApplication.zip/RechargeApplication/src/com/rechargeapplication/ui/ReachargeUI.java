package com.rechargeapplication.ui;
import java.time.LocalDate;
import java.util.Scanner;

import com.rechargeapplication.bean.Recharge;
import com.rechargeapplication.exception.InvalidNameException;
import com.rechargeapplication.exception.InvalidNumException;
import com.rechargeapplication.exception.InvalidPlanException;
import com.rechargeapplication.service.IRechargeService;
import com.rechargeapplication.service.RechargeServiceImp;

public class ReachargeUI
{
	static  IRechargeService iserv=null;
	static Scanner sc=new Scanner(System.in);
	static boolean res=true;
	
		public static void main(String[] args)
		{
			
			int a;
			do{
				
			System.out.println("1.recharge\n 2.view all transction \n 3.view by Tid \n4. update \n 5.delete");
			switch(sc.nextInt())
			{
				case 1:
					int	Rid1=AddRecharge();
					System.out.println("your recharge id :"+Rid1);
					
					System.out.println("recharge successful on:"+LocalDate.now());
								break;
					
				case 2:
					System.out.println("ALL TRANSCTIONS TILL :"+LocalDate.now());
					iserv.viewAllTransction();
					
					break;
					
				case 3:System.out.println("enter transction id  to view details");
					int Rid =sc.nextInt();
					iserv.viewByTid(Rid);
					System.out.println("DATE:"+LocalDate.now());
					
					break;
				case 4:System.out.println("enter id to update the details");
				int Rid3 =sc.nextInt();
				System.out.println("enter new name ");
				 String n=sc.next();
				 iserv.update(Rid3,n);
				 System.out.println("DETAILS UPDATED ON:"+LocalDate.now());
				
					break;
					
				case 5:
					System.out.println("enter transction id  to delete");
					int Rid2 =sc.nextInt();
					iserv.delete(Rid2);
					System.out.println(" deleted details ");
					System.out.println("TRANSCTION DETAILS DELETED ON:"+LocalDate.now());
				default:
					break;
					
			}
			System.out.println("do you wann continue y/n ");
			 a=sc.nextInt();
		}while(a!=0);
			
		
		
		}	
		static String name=null;
		static String mob=null;
		static String description=null;
		static String plantype=null;
		static String rechargetype;
		 static int rechargeAmt=0;
		
	 private static int AddRecharge()
	 {
		 iserv=new RechargeServiceImp();
		 res=false;	
		do {
			try 
			{
				System.out.println("enter the employee name");
				name = sc.next();
				res = iserv.validateName(name);
			} catch (InvalidNameException e){
					System.out.println(e.getMessage());
				}
			} while(!res);
		
		res=false;
		
		do {
			try {
				System.out.println("enter the mobile num");
				 mob = sc.next();
				res = iserv.validateNum(mob);
				} catch (InvalidNumException e) {
					System.out.println(e.getMessage());
				}
			} while(!res);
		
		res=false;
		
		do{
			try{
				System.out.println("enter the Plan type");
				plantype=sc.next();
				res = iserv.validatePlanType(plantype);
				}
			 catch (InvalidPlanException e) {
				System.out.println(e.getMessage());
			}
		} while(!res);
		res=false;		
			

		
				
				if(plantype.equals("prepaid"))
				{
					System.out.println("enter the reacharge type");
					
				
				System.out.println("1.RS199 \n  2.RS299\n");
				
				int  b=sc.nextInt();
				
					if(b==1)
					{
						rechargeAmt=199;
					System.out.println("recharge amt is:"+rechargeAmt);
					}
					else
					{
						rechargeAmt=299;
					System.out.println("recharge amt is :"+rechargeAmt);
					}
				}
				else
				{
					System.out.println("1.RS499 \n  2.RS599\n");
					int  b=sc.nextInt();
					if(b==1)
					{	
						rechargeAmt=499;
						System.out.println("recharge amt is:"+rechargeAmt);
					}
					else
					{	rechargeAmt=599;
						System.out.println("recharge amt is:"+rechargeAmt);
					}
				
				}
				System.out.println("enter the description");
				String description=sc.next();
				
				System.out.println("enter your amount");
				double amount=sc.nextInt();
				double amt=amount-rechargeAmt;
				System.out.println(amt);
				
				//LocalDate date=LocalDate.now();
			
			Recharge rc=new Recharge(name,mob,description,amt,rechargetype,plantype);
			
			
			int Rid =iserv.AddRecharge(rc);
			return Rid;
			}	
	 
	 public void viewAllTransction()
	 {
		 iserv.viewAllTransction();
	 }
	 public void viewByRid(int Rid)
	 {
		 iserv.viewByTid(Rid);
	 }
	 public void delete(int Rid)
	 {
		 iserv.delete(Rid);
	 }
	 public void update(int Rid,String name)
	 {
		 
		 iserv.update(Rid,name);
	 }
	 		
}
