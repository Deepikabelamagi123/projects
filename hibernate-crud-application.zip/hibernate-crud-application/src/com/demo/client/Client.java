package com.demo.client;

import com.demo.entity.Student;
import com.demo.service.StudentService;
import com.demo.service.StudentServiceImp;

public class Client {

	public static void main(String[] args) {

		//Debug this program as Debug -> Debug as Java Application
		
		StudentService service = new StudentServiceImp();
		
	Student student = new Student();
    student.setName("SMITHA");
	service.addStudent(student);
		
		//at this breakpoint, we have added one record to table
    student = service.findStudentById(141);
	System.out.print("ID:"+student.getStudentId());
	System.out.println(" Name:"+student.getName());
	
	student.setName("madhuLIKHA");
	service.updateStudent(student);
		
		//at this breakpoint, we have updated record added in first section
	student = service.findStudentById(112);
		System.out.print("ID:"+student.getStudentId());
	System.out.println(" Name:"+student.getName());
		
		//at this breakpoint, record is removed from table
	service.removeStudent(student);
	System.out.println("End of program...");
		
		
		

	}
}
