package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class JdbcDelete
{

	public static void main(String[] args) throws SQLException 
	{
		String url="jdbc:oracle:thin:@10.219.34.3:1521:orcl";
		String un="trg214";
		String pwd="training214";
		
		Connection conn=null;
		Scanner scan=new Scanner(System.in);
       conn=DriverManager.getConnection(url, un, pwd);
       
		
		Statement st=conn.createStatement();
		
		String query3="delete from EMP where ID=687";
		st.executeUpdate(query3);
		System.out.println("Row Deleted successfully ");
		conn.close();

		
	}

}	
	
