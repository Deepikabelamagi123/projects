package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
//import java.util.Scanner;

public class JdbcDemo1 
{
	public static void main(String[] args)
	{
		String url="jdbc:oracle:thin:@10.219.34.3:1521:orcl";
		String un="trg214";
		String pwd="training214";
		
		
		Connection con=null;
		try{
			con=DriverManager.getConnection(url, un, pwd);
			String qry="SELECT * FROM emp";
		 	Statement st=con.createStatement();
		 	ResultSet rs=st.executeQuery(qry);//table
		 	
		 	
		 	while(rs.next()){
		 		
		 		
		 			//System.out.println("hi");
		 		 	System.out.println(rs.getString(1));
		 		 	System.out.println(rs.getInt(2));
		 		 	System.out.println(rs.getInt(3));
		 		 	}
		 	
		 	
		} catch (SQLException e) {
				System.out.println("problem in DB OCCURED ::"+e.getMessage());
		}
		
	}}
		


