package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class JdbcInsert
{

	public static void main(String[] args) throws SQLException {
		String url="jdbc:oracle:thin:@10.219.34.3:1521:orcl";
		String un="trg214";
		String pwd="training214";
		Connection conn=null;
		Scanner scan=new Scanner(System.in);
		
		System.out.println("enter name: ");
		String name =scan.next();
		System.out.println("enter id : ");
		int  id=scan.nextInt();
		System.out.println("enter salary : ");
		int salary=scan.nextInt();

		conn=DriverManager.getConnection(url, un, pwd);
        String qry="INSERT INTO EMP VALUES('"+name+"',"+id+",'"+salary+"')";
		System.out.println(qry);
		Statement st=conn.createStatement();
		int status =st.executeUpdate(qry);
		
		
		
		
		
		
		//DML - delete,insert,update,merge
		if(status==1)
		{
			System.out.println(status + " inserted ");
		}
		else
		{
			System.out.println("not inserted ");
		}
	}

}

